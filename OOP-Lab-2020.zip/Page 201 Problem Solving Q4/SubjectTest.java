public class SubjectTest{
	public static void main(String args[]){

		Subject oop = new Subject("OOP","SCJ2153");
		Subject rse = new Subject("Real-Time Software Engineering","SCJ3253");

		oop.printInfo();
		rse.printInfo();

	}

}