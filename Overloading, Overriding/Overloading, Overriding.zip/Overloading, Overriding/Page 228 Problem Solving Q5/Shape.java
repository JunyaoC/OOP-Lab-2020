public class Shape{
		
	protected double area;

	public Shape(){

	}

	public double getArea(){
		return area;
	}


}